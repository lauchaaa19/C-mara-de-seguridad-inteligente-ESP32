#include <WiFi.h>
#include <ThingSpeak.h>

// -------------------- PINES --------------------
#define PIR_PIN 27       // Sensor de movimiento (PIR)
#define LDR_PIN 34       // Sensor de luz (salida analogica AO)
#define LED_PIN 23       // LED que simula la luz de la camara

// -------------------- WIFI --------------------
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// -------------------- THINGSPEAK --------------------
WiFiClient cliente;
unsigned long channelID = 358789;   // ID del canal
const char* apiKey = "KYVQJI8YIW1W3J1P";

// -------------------- VARIABLES --------------------
int movimiento = 0;
int valorLuz = 0;
int umbralOscuridad = 2000;

// Temporizadores usando millis()
unsigned long tiempoAnteriorLectura = 0;
unsigned long tiempoAnteriorEnvio = 0;

const unsigned long intervaloLectura = 500;    // Leer cada medio segundo
const unsigned long intervaloEnvio = 30000;    // Enviar cada 30 segundos

// -------------------- SETUP --------------------
void setup() {
  Serial.begin(115200);

  pinMode(PIR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // Conectarse al WiFi de Wokwi
  Serial.println("Conectando al WiFi...");
  WiFi.begin(ssid, password);

  // Esperar la conexion inicial (este delay esta en setup, no en loop)
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(500);
  }

  Serial.println();
  Serial.println("WiFi conectado!");

  // Inicializar la comunicacion con ThingSpeak
  ThingSpeak.begin(cliente);

  // Hacer que el primer envio ocurra despues de 30 segundos
  tiempoAnteriorEnvio = millis();
}

// -------------------- LOOP --------------------
void loop() {
  unsigned long tiempoActual = millis();

  // 1. Leer sensores cada 500 milisegundos
  if (tiempoActual - tiempoAnteriorLectura >= intervaloLectura) {
    tiempoAnteriorLectura = tiempoActual;

    movimiento = digitalRead(PIR_PIN); // HIGH (1) = movimiento
    valorLuz = analogRead(LDR_PIN);    // Valor analogico de luz (0 a 4095)

    // 2. Controlar el LED según movimiento y luminosidad

if (movimiento == HIGH && valorLuz < umbralOscuridad) {
  digitalWrite(LED_PIN, HIGH);
  Serial.println("Movimiento y oscuridad - LED ENCENDIDO");
} else {
  digitalWrite(LED_PIN, LOW);
  Serial.println("LED APAGADO");
}

    // 3. Mostrar las lecturas en el Monitor Serial
    Serial.print("Movimiento: ");
    Serial.println(movimiento);

    Serial.print("Nivel de luz: ");
    Serial.println(valorLuz);
    Serial.println("-------------------------");
  }

  // 4. Enviar datos a ThingSpeak cada 30 segundos
  if (tiempoActual - tiempoAnteriorEnvio >= intervaloEnvio) {
    tiempoAnteriorEnvio = tiempoActual;

    if (WiFi.status() == WL_CONNECTED) {
      ThingSpeak.setField(1, movimiento); // Field 1: movimiento (0 o 1)
      ThingSpeak.setField(2, valorLuz);   // Field 2: nivel de luz

      int respuesta = ThingSpeak.writeFields(channelID, apiKey);

      if (respuesta == 200) {
        Serial.println("Datos enviados correctamente a ThingSpeak!");
      } else {
        Serial.print("Error al enviar datos. Codigo: ");
        Serial.println(respuesta);
      }
    } else {
      Serial.println("WiFi desconectado: no se enviaron datos.");
    }
  }
}


